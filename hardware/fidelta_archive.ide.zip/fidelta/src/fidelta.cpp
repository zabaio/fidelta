#include <stdio.h>
#include <stdlib.h>
#include <chrono>
#include <assert.h>
#include <string.h>

#define CL_HPP_CL_1_2_DEFAULT_BUILD
#define CL_HPP_TARGET_OPENCL_VERSION 120
#define CL_HPP_MINIMUM_OPENCL_VERSION 120
#define CL_HPP_ENABLE_PROGRAM_CONSTRUCTION_FROM_ARRAY_COMPATIBILITY 1
#define CL_USE_DEPRECATED_OPENCL_1_2_APIS


#include <CL/opencl.h>
#include <CL/cl_ext.h>

#define OCL_CHECK(error,call)                                       \
    call;                                                           \
    if (error != CL_SUCCESS) {                                      \
      printf("%s:%d Error calling " #call ", error code is: %d\n",  \
              __FILE__,__LINE__, error);                            \
      exit(EXIT_FAILURE);                                           \
    }

#include "types.h"
#include "display.h"

#ifndef MAXQUERY
    #define MAXQUERY 1000000
#endif
#ifndef PTSLIM
    #define PTSLIM 5000000
#endif

// Merges the enc arrays of father and uncle, copying the resulting IDs in accel_state and their coordinates in accel_data
void merge (t_node *father, int *fid, t_node *uncle, int *uid, float accel_data[], int accel_state[], int *bookmark);

int main(int argc, char *argv[])
{
    int rmode = 0, n_pts, i;
    float max_cor;

    //node: file where we store generated points/a copy of those in input
    //extnode: eventual input point file
    FILE *node, *extnode; 

    //start init time profiling
    auto time_start = std::chrono::steady_clock::now();

    // reads command line arguments, returns selected mode (random or from file), starts initializing node file
    rmode = init_cmd (argc, argv, &node, &extnode, &n_pts, &max_cor);


    // --- Start OpenCL initialization --- //

    cl_int err;

    // Platform
    char cl_platform_vendor[1001];
    char cl_platform_name[1001];
    cl_uint platform_count;
	cl_platform_id platform_id;
	cl_platform_id platforms[16];

	OCL_CHECK (err, err = clGetPlatformIDs(16, platforms, &platform_count));
	for (cl_uint count = 0; count < platform_count; count++){
		OCL_CHECK (err, err = clGetPlatformInfo(platforms[count], CL_PLATFORM_VENDOR,
						      1000, (void *)cl_platform_vendor, NULL));
		if (strcmp(cl_platform_vendor, "Xilinx") == 0){
			printf("Found platform vendor: %s\n", cl_platform_vendor);
			platform_id = platforms[count];
			break;
		}
		if (count == platform_count - 1){
			printf("No Xilinx platform found\n");
			exit(EXIT_FAILURE);
		}
	}

	OCL_CHECK (err, err = clGetPlatformInfo(platform_id, CL_PLATFORM_NAME,
						  1000, (void *)cl_platform_name, NULL));
	printf("Found platform name: %s\n", cl_platform_vendor);

	// Device
	cl_device_id device_id;
	char cl_device_name[1001];

	OCL_CHECK (err, err = clGetDeviceIDs(platform_id, CL_DEVICE_TYPE_ACCELERATOR,
			              1, &device_id, NULL));
	OCL_CHECK (err, err = clGetDeviceInfo(device_id, CL_DEVICE_NAME,
			              1000, (void *)cl_device_name, NULL));
    printf("Found device name: %s\n", cl_device_name);

    // Context and queue
    cl_context context;
    cl_command_queue q;

    OCL_CHECK (err, context = clCreateContext (NULL, 1, &device_id, NULL, NULL, &err));
    OCL_CHECK (err, q = clCreateCommandQueue (context, device_id,
    					CL_QUEUE_PROFILING_ENABLE, &err));

    // Program and kernel
    char *xclbin_name = argv[1];
    char *kernelbinary;
    cl_program program;
    cl_kernel krnl_incircle;

    size_t size = load_xclbin(xclbin_name, &kernelbinary);
    OCL_CHECK (err, program = clCreateProgramWithBinary(context, 1, &device_id, &size,
    			              (const unsigned char **) &kernelbinary, NULL, &err));
    OCL_CHECK (err, krnl_incircle = clCreateKernel(program, "accel_in_circle", &err));

    // Buffers and arguments
    float *accel_data;
    int *accel_state;
    int *accel_result;
    int *sym_accel_result;
    int bookmark;
    cl_mem data_buf;
    cl_mem state_buf;
    cl_mem result_buf;

    OCL_CHECK (err, err = posix_memalign((void **) &accel_data, 4096, 8*MAXQUERY * sizeof(float)));
    OCL_CHECK (err, err = posix_memalign((void **) &accel_state, 4096, MAXQUERY * sizeof(int)));
    OCL_CHECK (err, err = posix_memalign((void **) &accel_result, 4096, MAXQUERY * sizeof(int)));
    OCL_CHECK (err, err = posix_memalign((void **) &sym_accel_result, 4096, MAXQUERY * sizeof(int)));

	OCL_CHECK (err, data_buf = clCreateBuffer(context, CL_MEM_WRITE_ONLY | CL_MEM_USE_HOST_PTR,
			                   8*MAXQUERY*sizeof(float), accel_data, NULL));

	OCL_CHECK (err, state_buf = clCreateBuffer(context, CL_MEM_WRITE_ONLY | CL_MEM_USE_HOST_PTR,
    				            MAXQUERY * sizeof (int), accel_state, NULL));

	OCL_CHECK (err, result_buf = clCreateBuffer(context, CL_MEM_READ_ONLY | CL_MEM_USE_HOST_PTR,
    				            MAXQUERY * sizeof (int), accel_result, NULL));

	OCL_CHECK (err, err = clSetKernelArg(krnl_incircle, 0, sizeof(cl_mem), &data_buf));
	OCL_CHECK (err, err = clSetKernelArg(krnl_incircle, 1, sizeof(cl_mem), &state_buf));
	OCL_CHECK (err, err = clSetKernelArg(krnl_incircle, 2, sizeof(cl_mem), &result_buf));

	// ----- End OpenCL initialization ---- //


	// --- Start reading input data set --- //

    if (rmode)
        init_random(&node, n_pts, max_cor);
    else
        init_from_file(&extnode, &node, &n_pts);

    // Now "node" stores all the points needed.
    // We create tris, the core structure of the algorithm.
    // It is a list of triangles, each one with the array of points that encroach on it, 
    // meaning that they are inside the triangle's circumcircle
    // The first three points in result.node form a triangle bounding all other points, which we add to tris.
    // Then we add every point to its encroaching points array.

    t_node *tris = NULL;

    // Simple array of points which we then fill with those in the node file
    point *pts = (point *) malloc((PTSLIM + 3) * sizeof(point));    

    fseek(node, 0, SEEK_SET);
    fscanf (node, "%*[^\n]\n");
    for (i = 0; i < 3; i++){
        fscanf (node, "%d %f %f \n", &pts[i].id, &pts[i].x, &pts[i].y);       
    }
    push_t(&tris, pts[0], pts[1], pts[2]);
    tris->dim = n_pts;
    tris->enc = (point *) malloc(tris->dim*sizeof(point));
    for (i = 0; i < n_pts; i++){
        fscanf (node, "%d %f %f \n", &(tris->enc[i].id), &(tris->enc[i].x), &(tris->enc[i].y));
        pts[i+3] = tris->enc[i];
		#ifdef LOG
        	print_pt (pts[i+3]);
		#endif
    }

    fclose (node);

    // Initialization of the hash table segs
    // It stores every segment generated, hashed on the points ids,
    // and their (up to two) adjacent triangles
    // We start by adding the three artificial bounding segments

    record_segs *segs = NULL;
    segs_add (&segs, tris->t.p1, tris->t.p2, tris);
    segs_add (&segs, tris->t.p2, tris->t.p3, tris);
    segs_add (&segs, tris->t.p3, tris->t.p1, tris);

    // Initialization of the active segments list acts.
    // Each element of acts represents a future triangle generation.
    // The triangle it will generate is made by linking the segment acts->act
    // to the first encroached point (in order of id) of acts->father.
    // Acts is filled in rounds. Within each round all elements are independent, 
    // so all merge and inCircle calls could be processed simultaneously
    // When a round ends nextround is loaded in acts.

    act_node *acts = NULL;
    act_node *nextround = NULL;

    // The first three active segments are added, their father being the bounding triangle

    push_act (&nextround, segs, tris->t.p1, tris->t.p2, tris);
    push_act (&nextround, segs, tris->t.p2, tris->t.p3, tris);
    push_act (&nextround, segs, tris->t.p3, tris->t.p1, tris);
    
    #ifdef LOG
        int roundcount = 0, roundwidth = 0;
    #endif

    // End init profiling

    auto time_end = std::chrono::steady_clock::now();
    int init_time = std::chrono::duration_cast<std::chrono::milliseconds>(time_end - time_start).count();

    // ------- End of data set input ------ //

    // --- Start Delaunay Triangulation --- //

    // Start triangulation time profiling
    time_start = std::chrono::steady_clock::now();

    // We found necessary performing a first dummy execution of the openCl task in order to avoid errors
    bookmark = 0;
	OCL_CHECK (err, err = clSetKernelArg(krnl_incircle, 3, sizeof(int), &bookmark));
	OCL_CHECK (err, err = clEnqueueTask(q, krnl_incircle, 0, NULL, NULL));
	OCL_CHECK (err, err = clFinish(q));

	// The algorithm continues until there are no more active segments
    while(acts != NULL || nextround != NULL){

        // If if the list of current acts has ended, we load the next round.
    	// We then generate all at once the new round triangles, and fill them with their encroaching points
        if (acts == NULL){
            #ifdef LOG
                printf ("Round width: %d\n", roundwidth);
                roundwidth = 0;
                roundcount++;
            #endif
            #ifdef DEBUG
                printf("Fine round;\n");
                print_tris_id(tris);
            #endif

            // Load round
            acts = nextround;
            nextround = NULL;

            act_node *aprobe = acts;
            t_node *tprobe = tris;

            // Generate new triangle
            push_t (&tprobe, aprobe->act->seg.a, aprobe->act->seg.b, aprobe->father->enc[0]); 
            
            // Allocate its enc array.
            // It can't be bigger then the sum of its parent's arrays, so we use that as an upper bound
            int alldim = 0;
            if(aprobe->act->tfirst != NULL)
                alldim += aprobe->act->tfirst->dim;
            if(aprobe->act->tsecond != NULL)
                alldim += aprobe->act->tsecond->dim;
            tprobe->enc = (point *)malloc(alldim*sizeof(point));

            // data_ref lets us remember the triangle associated to each query in accel_data
            t_node *data_ref[MAXQUERY];
            int fid = 1, uid = 0;

            while (aprobe != NULL){
                
                int ndone;
                int complete;
                bookmark = 0;

                // We continue to fill the buffers until we reach their size
                // or if there are no more queries to send to the FPGA in this round
                while (bookmark < MAXQUERY && aprobe != NULL){

                    ndone = bookmark;
                    merge (aprobe->father, &fid, aprobe->uncle, &uid, accel_data, accel_state, &bookmark);
                    ndone = bookmark - ndone;

                    if (fid + uid < alldim)
                        complete = 0;
                    else{
                        complete = 1;
                        fid = 1;
                        uid = 0;
                    }

                    // We finish filling the buffer with the coordinates of new triangle
                    // The FPGA will need them to perform the inCircle test
                    for (i = 1; i <= ndone; i++){
						data_ref[bookmark - i] = tprobe;
						accel_data[(bookmark - i)*8 + 2] = tprobe->t.p1.x;
						accel_data[(bookmark - i)*8 + 3] = tprobe->t.p1.y;
						accel_data[(bookmark - i)*8 + 4] = tprobe->t.p2.x;
						accel_data[(bookmark - i)*8 + 5] = tprobe->t.p2.y;
						accel_data[(bookmark - i)*8 + 6] = tprobe->t.p3.x;
						accel_data[(bookmark - i)*8 + 7] = tprobe->t.p3.y;
                    }

                    // If we've finished the queries of this triangle we pass to the next
                    if (complete){
                        aprobe = aprobe->next;
                        if (aprobe != NULL){

                        	push_t (&tprobe, aprobe->act->seg.a, aprobe->act->seg.b, aprobe->father->enc[0]);

                            alldim = 0;
                            if(aprobe->act->tfirst != NULL)
                                alldim += aprobe->act->tfirst->dim;
                            if(aprobe->act->tsecond != NULL)
                                alldim += aprobe->act->tsecond->dim;
                            tprobe->enc = (point *)malloc(alldim*sizeof(point));
                        }
                    }
                }

                // If we need no more tests (happens in the last rounds) we move on
                if (bookmark == 0)
                	continue;

                // The inCircle kernel needs an even number of queries since it computes
                // 2 inCircle tests for each iteration
                if (bookmark % 2 == 1){
                    accel_state[bookmark] = -1;
                	bookmark ++;
                }

                cl_event evts[5];

                // We set the number of tests the FPGA will need to perform
            	OCL_CHECK (err, err = clSetKernelArg(krnl_incircle, 3, sizeof(int), &bookmark));

            	// Then all the data needed is transferred
            	OCL_CHECK (err, err = clEnqueueWriteBuffer(q, data_buf, CL_FALSE, 0, 8*bookmark*sizeof(float), accel_data, 0, NULL, evts));
				OCL_CHECK (err, err = clEnqueueWriteBuffer(q, state_buf, CL_FALSE, 0, bookmark*sizeof(int), accel_state, 0, NULL, evts+1));
				OCL_CHECK (err, err = clFinish(q));

				// The FPGA performs the task
				OCL_CHECK (err, err = clEnqueueTask(q, krnl_incircle, 0, NULL, (evts + 2)));
				OCL_CHECK (err, err = clFinish(q));

				// The results are copied back
				OCL_CHECK (err, err = clEnqueueReadBuffer(q, result_buf, CL_FALSE, 0, bookmark*sizeof(int), accel_result, 0, NULL, (evts + 3)));
				OCL_CHECK (err, err = clFinish(q));

				// accel_result stores the id of the point if it actually encroaches the new triangle.
				// If so, we add it to the appropriate array
				// If instead it doesn't the FPGA will return a -1 id, and we move on

				for (int i = 0; i < bookmark; i++){
                	if(accel_result[i] != -1){
                		data_ref[i]->enc[data_ref[i]->dim] = pts[accel_result[i]];
                		data_ref[i]->dim ++;
                	}
                }
            }
        }

        #ifdef LOG
            roundwidth++;
        #endif
        
        // All new triangles of the round are in tris.
        // Now the rest of the process consists in going through each of them,
        // updating the segs hash table and finding the next active segments.
        // We take the next one:

        tris = tris->prev;

        // We add one of its segment to segs.
        // If the segment already existed, on it's other side there's already a triangle.
        // In that case we find which one, beteween the new neighboring triangles, has the lowest-id point.
        // That triangle will be deleted in the next round, so we add it to nextround along with the segment.
        // Else, if their lowest-id point is the same, no triangle will be deleted, we do nothing.

        t_node *encroached = NULL;
        encroached = segs_add (&segs, acts->act->seg.a, acts->father->enc[0], tris);
        
        if (encroached != NULL){
            push_act (&nextround, segs, acts->act->seg.a, acts->father->enc[0], encroached);
        }

        // Same as before, but considering the second new segment
        encroached = segs_add (&segs, acts->act->seg.b, acts->father->enc[0], tris);
        
        if (encroached != NULL){
            push_act (&nextround, segs, acts->act->seg.b, acts->father->enc[0], encroached);
        }
        
        #ifdef DEBUG
        	assert (acts->act->tfirst == acts->father || acts->act->tsecond == acts->father);
		#endif

		// Now we check if act is still active even after having replaced it's father with son.
		// If uncle is null we're on the border.
        // We update its only adjacent triangle, and if the new one has still enc pts we add it to nextround.

		if(acts->uncle == NULL){
            acts->act->tfirst = tris;
            if (tris->dim != 0){
                push_act (&nextround, segs, acts->act->seg.a, acts->act->seg.b, tris);
            }
        }

        // If uncle isn't null we find which triangle of the two adjecent is the father and replace it,
        // then we check if the common segment is active, on both sides
        else{
            
            // Checking who's the father and replacing it with the son
            if (acts->act->tfirst == acts->father){
                acts->act->tfirst = tris;
            }
            else{ 
                acts->act->tsecond = tris;
            }

            // Checking if the first adjacent triangle added in segs is going to die in next round.
            if (acts->act->tfirst->dim != 0 && 
               (acts->act->tsecond->dim == 0 || acts->act->tfirst->enc[0].id  <  acts->act->tsecond->enc[0].id)){
                
                push_act (&nextround, segs, acts->act->seg.a, acts->act->seg.b, acts->act->tfirst);
            
            }

            // Same thing but with the second triangle
            else if (acts->act->tsecond->dim != 0 && 
                    (acts->act->tfirst->dim == 0 || acts->act->tsecond->enc[0].id  <  acts->act->tfirst->enc[0].id)){

                push_act (&nextround, segs, acts->act->seg.a, acts->act->seg.b, acts->act->tsecond);
            
            }
        }

		// We pass to the next active segment
        pop_act (&acts);


    }

    // ---- End Delaunay Triangulation ----- //


    // --- Cleanup, output and profiling --- //


    clReleaseCommandQueue(q);
    clReleaseContext(context);
    clReleaseDevice(device_id);
    clReleaseKernel(krnl_incircle);
    clReleaseProgram(program);
    clReleaseMemObject(data_buf);
    clReleaseMemObject(state_buf);
    clReleaseMemObject(result_buf);
    
	time_end = std::chrono::steady_clock::now();
	int delaunay_time = std::chrono::duration_cast<std::chrono::milliseconds>(time_end - time_start).count();

	// Start output time profiling
    time_start = std::chrono::steady_clock::now();

    // Prints on result.ele file all the triangles generated, minus those connected to the start bounding triangle,
    // since it wasn't part of the original triangulation
    print_result (tris, n_pts);

    time_end = std::chrono::steady_clock::now();
	int output_time = std::chrono::duration_cast<std::chrono::milliseconds>(time_end - time_start).count();

	// Print time results
    printf("Init time: %d ms\n", init_time);
    printf("Delaunay time: %d ms\n", delaunay_time);
    printf("Writing output: %d ms\n\n", output_time);

    #ifdef LOG
        printf ("Number of rounds: %d\n", roundcount);
    #endif

    return 0;
}

void merge (t_node *father, int *infid, t_node *uncle, int *inuid, float accel_data[], int accel_state[], int *inbookmark){

    // We discard the fist point of father since is a vertex of son.
    // If there's no uncle we just test the father's vertices and add them to son
    point *fenc = father->enc;
    int fid = *infid;
    int uid = *inuid;
    int bookmark = *inbookmark;
    
    if (uncle == NULL){
        for(; fid < father->dim && bookmark < MAXQUERY; fid++){
            accel_state[bookmark] = fenc[fid].id;
            accel_data[bookmark*8] = fenc[fid].x;
            accel_data[bookmark*8 + 1] = fenc[fid].y;
            (bookmark) ++;
        }
    }
    else{

        // If uncle exists we merge its and father's encroaching point lists
        // and add it to son, while maintaining the order of the ids
        point *uenc = uncle->enc;
        while ((fid < father->dim || uid < uncle->dim) && bookmark < MAXQUERY){
            
            if (uid == uncle->dim || (fid < father->dim && fenc[fid].id < uenc[uid].id)){
                accel_state[bookmark] = fenc[fid].id;
                accel_data[bookmark*8] = fenc[fid].x;
                accel_data[bookmark*8 + 1] = fenc[fid].y;
                bookmark ++;
                fid ++;
            }
            
            else if (fid == father->dim || (uid < uncle->dim && uenc[uid].id < fenc[fid].id)){
                accel_state[bookmark] = uenc[uid].id;
                accel_data[bookmark*8] = uenc[uid].x;
                accel_data[bookmark*8 + 1] = uenc[uid].y;
                bookmark ++;
                uid ++;
            }

            else if (fid < father->dim && uid < uncle->dim && fenc[fid].id == uenc[uid].id){
                accel_state[bookmark] = fenc[fid].id;
                accel_data[bookmark*8] = fenc[fid].x;
                accel_data[bookmark*8 + 1] = fenc[fid].y;
                (bookmark) ++;
                (uid) ++;
                (fid) ++;
            }
        }
    }

    *infid = fid;
    *inuid = uid;
    *inbookmark = bookmark;
    return;
}

